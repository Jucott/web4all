<?php

date_default_timezone_set('Europe/Paris');
require_once __DIR__ . '/../app/config/Constants.php';




/**
 * Chargement du fichier .env situé à la racine du projet
 *
 * @param string $path nom du fichir à loader
 * 
 * Charge dans la variable d'environnement $_ENV les données présente dans le fichier .env
 *
 * @return void
 */
function loadEnv($path)
{
    if (!file_exists($path)) return;

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue;

        [$key, $value] = explode('=', $line, 2);

        $key = trim($key);
        $value = trim($value);

        putenv("$key=$value");
        $_ENV[$key] = $value;
    }
}

loadEnv(__DIR__ . '/../.env');
// session_set_cookie_params([
//     'lifetime' => 0,
//     'path' => '/',
//     'domain' => 'web4all.local',    // ton domaine
//     'secure' => false,              // mettre true -> HTTPS obligatoire
//     'httponly' => true,             // impossible d’y accéder via JS
//     'samesite' => 'Strict'          // ou Lax selon besoin
// ]);
session_start();

var_dump($_SESSION);

require_once __DIR__ . '/../app/core/Autoloader.php';
Autoloader::register();

// Initialisation permissions guest si non définies
if (!isset($_SESSION['permissions'])) {

    $db = Database::getInstance();

    $stmt = $db->prepare("
        SELECT permission
        FROM permission
        WHERE id_role = 4 AND allowed = true
    ");
    $stmt->execute();

    $_SESSION['permissions'] = $stmt->fetchAll(PDO::FETCH_COLUMN);
}


$router = new Router();
$router->dispatch();
