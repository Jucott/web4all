<h2>Création d'offre</h2>

<script src="<?= CDN ?>/js/modules/offre.js"></script>


<?php if (!empty($errors)) : ?>
    <div class="error-box">
        <?php foreach ($errors as $fieldErrors) : ?>
            <?php foreach ($fieldErrors as $error) : ?>
                <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form id="formOffre" data-validate="true" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <label for="titre">Titre</label>
    <input type="text" id="titre" name="titre" value="<?= htmlspecialchars($filters['titre'] ?? '', ENT_QUOTES, 'UTF-8') ?>" data-validate="required|alpha">

    <label for="description">Description</label>
    <textarea name="description" id="description" data-validate="required|txt"><?= htmlspecialchars($filters['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>

    <label for="base_remuneration">Base de rémunération</label>
    <input type="number" name="base_remuneration" id="base_remuneration" value="<?= htmlspecialchars($filters['base_remuneration'] ?? '', ENT_QUOTES, 'UTF-8') ?>" data-validate="required|integer">

    <label for="date_offre">Date de l'offre</label>
    <input type="date" id="date_offre" name="date_offre" value="<?= htmlspecialchars($filters['date_offre'] ?? '', ENT_QUOTES, 'UTF-8') ?>" data-validate="required|date">

    <label> Active
        <input type="checkbox"
            name="valide"
            value="1"
            <?= !isset($filters['valide']) ? 'checked' : ($filters['valide'] ? 'checked' : '') ?>>
    </label>

    <label>Entreprise</label>
    <select name="id_entreprise">
        <option value="">-- Choisir une entreprise --</option>
        <?php foreach ($entreprises as $entreprise): ?>
            <option value="<?= $entreprise['id_entreprise'] ?>"
                <?= (isset($filters['id_entreprise']) && (string)($filters['id_entreprise']) === (string)($entreprise['id_entreprise'])) ? 'selected' : '' ?>>
                <?= htmlspecialchars($entreprise['nom']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <hr/>

    <label>Compétences requises</label>

    <select id="competence-select">
        <option value="">-- Choisir une compétence --</option>
        <?php foreach ($competences as $c): ?>
            <option value="<?= $c['id_competence'] ?>">
                <?= htmlspecialchars($c['competence']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="button" id="add-competence">Ajouter</button>

    <div id="competences-container" class="competences-container">
        <p class="placeholder">Aucune compétence sélectionnée</p>
    </div>

    <hr/>
    
    <button type="submit">Sauve</button>
    <button type="button" onclick="window.location.href='/offre/recherche'">Annule</button>

</form>

