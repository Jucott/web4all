<div class="content">
    <h1>Mentions Légales</h1>

    <section class="home-intro">
        <p>Conformément à l'article 6 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l'économie numérique, il est précisé aux utilisateurs du site l'identité des différents intervenants dans le cadre de sa réalisation et de son suivi :</p>
    </section>

    <section class="home-description">
        <h2>Éditeur du site</h2>
        <p><strong>Nom de l'entreprise : </strong>StageFinder SARL</p>
        <p><strong>Numéro SIRET : </strong>123 456 789 00011</p>
        <p><strong>Forme juridique : </strong>Société à Responsabilité Limitée (SARL)</p>
        <p><strong>Capital social : </strong>10 000 EUR</p>
        <p><strong>Adresse du siège social : </strong>1 Rue des Étudiants, 75000 Paris, France</p>
    </section>

    <section class="home-description">
        <h2>Directeur de la publication</h2>
        <p><strong>Nom : </strong>Jean Dupont</p>
        <p><strong>Email : </strong>contact@stagefinder.fr</p>
    </section>

    <section class="home-description">
        <h2>Hébergement</h2>
        <p><strong>Hébergeur : </strong>HostTech Solutions</p>
        <p><strong>Adresse : </strong>20 Rue de l'Hébergement, 75001 Paris, France</p>
        <p><strong>Contact : </strong>support@hosttech.com</p>
    </section>

    <section class="home-description">
        <h2>Objet du site</h2>
        <p>Le site <strong>StageFinder</strong> est une plateforme en ligne permettant aux étudiants de rechercher des offres de stage et d'alternance, de postuler à ces offres et de suivre leur progression. Ce site est destiné à faciliter la mise en relation entre les étudiants et les entreprises, ainsi qu’à offrir un outil de gestion pour les enseignants et responsables pédagogiques encadrant les projets.</p>
    </section>

    <section class="home-description">
        <h2>Propriété intellectuelle</h2>
        <p>Le contenu du site (textes, images, logos, vidéos, etc.) est protégé par les lois françaises et internationales relatives à la propriété intellectuelle. Tous les droits sont réservés à <strong>StageFinder SARL</strong>, sauf mention contraire. Toute reproduction, diffusion, modification, ou exploitation de tout ou partie du site, sans l'autorisation préalable de l'éditeur, est interdite et constitue une contrefaçon, conformément aux dispositions des articles L.335-2 et suivants du Code de la propriété intellectuelle.</p>
    </section>

    <section class="home-description">
        <h2>Protection des données personnelles</h2>
        <p>Conformément au Règlement Général sur la Protection des Données (RGPD) et à la loi Informatique et Libertés, <strong>StageFinder</strong> s'engage à protéger la confidentialité des données personnelles de ses utilisateurs. Les informations collectées sur ce site sont utilisées uniquement dans le cadre de la gestion des offres de stage et alternance et de la communication entre les étudiants, les entreprises et les enseignants.</p>
        <p>Les utilisateurs peuvent à tout moment exercer leur droit d'accès, de rectification, de suppression et d'opposition concernant leurs données personnelles, en envoyant une demande à l'adresse suivante : <strong>contact@stagefinder.fr</strong>.</p>
    </section>

    <section class="home-description">
        <h2>Utilisation des cookies</h2>
        <p>Lors de votre navigation sur notre site, des cookies peuvent être installés sur votre terminal. Ces cookies sont utilisés uniquement dans le cadre de l'authentification des utilisateurs. Ils permettent de mémoriser votre session lorsque vous êtes connecté, afin de faciliter votre navigation et éviter que vous ayez à vous reconnecter à chaque page. Aucun cookie de suivi ou de traçage n'est utilisé pour collecter des informations sur vos habitudes de navigation.</p>
        <p>Les cookies sont strictement nécessaires pour l'accès aux fonctionnalités de connexion et de gestion de votre compte utilisateur. Vous pouvez, si vous le souhaitez, paramétrer votre navigateur pour refuser l'utilisation de ces cookies. Toutefois, cela pourra entraîner des difficultés d'utilisation du site, notamment pour l'accès aux fonctionnalités liées à l'authentification.</p>
    </section>

    <section class="home-description">
        <h2>Liens hypertextes</h2>
        <p>Le site <strong>StageFinder</strong> peut contenir des liens hypertextes vers d'autres sites. Nous déclinons toute responsabilité quant au contenu de ces sites externes, qui sont soumis à leurs propres mentions légales. L'insertion de liens vers ce site est autorisée, sous réserve de mentionner clairement la source et de ne pas altérer le contenu du site. Toute utilisation abusive des liens est interdite.</p>
    </section>

    <section class="home-description">
        <h2>Responsabilité</h2>
        <p>Les informations contenues sur ce site sont fournies à titre indicatif. L'éditeur s'efforce d'assurer l'exactitude des informations, mais ne saurait être tenu responsable des erreurs ou omissions qui pourraient y figurer. L'utilisateur est responsable de l'utilisation qu'il fait des informations disponibles sur ce site.</p>
    </section>
    
    <div class="contact-info">
        <p>Pour toute question relative à ce site, vous pouvez nous contacter à l'adresse suivante : <strong>contact@stagefinder.fr</strong></p>
    </div>
</div>