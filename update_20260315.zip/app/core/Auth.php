<?php

class Auth
{
    public static function user()
    {
        return $_SESSION['user'] ?? null;
    }

    public static function check()
    {
        return isset($_SESSION['user']);
    }

    public static function role()
    {
        return $_SESSION['user']['role'] ?? 'guest';
    }

    public static function can($permission)
    {
        if (!isset($_SESSION['permissions'])) {
            return false;
        }

        return $_SESSION['permissions'][$permission] ?? false;
    }

    public static function logout()
    {
        $_SESSION = [];
        session_destroy();
    }
}