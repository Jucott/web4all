<?php

class AdminController extends Controller
{

    public function permissions()
    {

        if ($_SESSION['user']['role'] !== 'administrateur') {
            http_response_code(403);
            die('Accès interdit');
        }

        $model = new Permission();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            foreach ($_POST['permissions'] as $role => $pages) {

                foreach ($pages as $page => $value) {

                    $model->setPermission($role, $page, $value);

                }

            }

        }

        $permissions = $model->all();

        $this->render('admin/permissions', [
            'permissions' => $permissions
        ]);
    }

}