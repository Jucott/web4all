<?php

class Permission extends Model
{

    public function all()
    {
        $stmt = $this->db->query("SELECT * FROM permission");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function setPermission($id_role, $permission, $allowed)
    {

        $sql = "
        UPDATE permission
        SET allowed = :allowed
        WHERE id_role = :id_role
        AND permission = :permission
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            'allowed' => $allowed,
            'id_role' => $id_role,
            'permission' => $permission
        ]);
    }
}