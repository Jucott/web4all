<h1>Gestion des permissions</h1>

<form method="post">

<table>

<tr>
<th>Role</th>
<th>Page</th>
<th>Autorisé</th>
</tr>

<?php foreach ($permissions as $p): ?>

<tr>

<td><?= $p['id_role'] ?></td>

<td><?= $p['page'] ?></td>

<td>

<input type="checkbox"
name="permissions[<?= $p['id_role'] ?>][<?= $p['page'] ?>]"
value="1"
<?= $p['permission'] ? 'checked' : '' ?>

>

</td>

</tr>

<?php endforeach ?>

</table>

<button type="submit">Sauvegarder</button>

</form>