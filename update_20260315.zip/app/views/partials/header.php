<header class="header">
    <div class="logo"><img src="/app-icons/icon-192.png" alt="LOGO" width="30" height="30"></div>
    <h1 class="title">Web4All</h1>
    <div class="burger">☰</div>

    <nav class="nav">
        <ul>
            <li><a href="/">Accueil</a></li>

            <li>Entreprises
                <ul>
                    <li><a href="/entreprise/recherche">Recherche</a></li>
                    <?php if (Auth::check()): ?>
                        <li><a href="/entreprise/create">Créer</a></li>
                    <?php endif ?>
                </ul>
            </li>

            <li>Offres
                <ul>
                    <li><a href="/offre/recherche">Recherche</a></li>
                    <?php if (Auth::check()): ?>
                        <li><a href="/offre/create">Créer</a></li>
                    <?php endif ?>
                </ul>
            </li>
            <?php if (Auth::check()): ?>
                <li>Pilotes
                    <ul>
                        <li><a href="/pilote/recherche">Recherche</a></li>
                        <li><a href="/pilote/create">Créer</a></li>
                    </ul>
                </li>

                <li>Etudiants
                    <ul>
                        <li><a href="/etudiant/recherche">Recherche</a></li>
                        <li><a href="/etudiant/create">Créer</a></li>
                    </ul>
                </li>

                <li>Candidatures
                    <ul>
                        <li><a href="/candidature/recherche">Recherche</a></li>
                        <li><a href="/candidature/create">Créer</a></li>
                    </ul>
                </li>

                <li>Wish-list 
                    <ul>
                        <li><a href="/wishlist/recherche">Recherche</a></li>
                        <li><a href="/wishlist/create">Créer</a></li>
                    </ul>
                </li>
            <?php endif ?>

            <?php if (Auth::check()): ?>

            <li>
            <a href="/auth/logout">Logout</a>
            </li>

            <?php else: ?>

            <li>
            <a href="/auth/login">Login</a>
            </li>

            <?php endif ?>

        </ul>
    </nav>
</header>
