<div class="container">
    <h1>Contact</h1>
    <p>Pour toute question concernant la plateforme de gestion des stages et alternances, vous pouvez contacter les responsables ci-dessous :</p>

    <h2>Responsable de l'école</h2>
    <div class="card">
        <p class="role">Directeur de l'établissement</p>
        <p class="info"><strong>Nom :</strong> Pierre Martin</p>
        <p class="info"><strong>Email :</strong> pierre.martin@ecole-exemple.fr</p>
        <p class="info"><strong>Téléphone :</strong> 01 23 45 67 89</p>
    </div>

    <h2>Administration</h2>
    <div class="card">
        <p class="role">Responsable des relations entreprises</p>
        <p class="info"><strong>Nom :</strong> Sophie Bernard</p>
        <p class="info"><strong>Email :</strong> sophie.bernard@ecole-exemple.fr</p>
        <p class="info"><strong>Téléphone :</strong> 01 98 76 54 32</p>
    </div>

    <h2>Pilotes pédagogiques</h2>

    <div class="card">
        <p class="role">Pilote groupe A</p>
        <p class="info"><strong>Nom :</strong> Julien Moreau</p>
        <p class="info"><strong>Email :</strong> julien.moreau@ecole-exemple.fr</p>
    </div>

    <div class="card">
        <p class="role">Pilote groupe B</p>
        <p class="info"><strong>Nom :</strong> Claire Dubois</p>
        <p class="info"><strong>Email :</strong> claire.dubois@ecole-exemple.fr</p>
    </div>

    <div class="card">
        <p class="role">Pilote groupe C</p>
        <p class="info"><strong>Nom :</strong> Thomas Leroy</p>
        <p class="info"><strong>Email :</strong> thomas.leroy@ecole-exemple.fr</p>
    </div>

</div>